<h1>Display data from DB</h1>
<?php

include('mysqli_connect.php');

$sqlget = "SELECT * FROM people";
$sqldata = mysqli_query($dbc, $sqlget) or die ('error getting data');

    
echo "<table>";
echo "<tr><th>ID</th><th>First Name</th><th>Last Name</th></tr>";

while($row = mysqli_fetch_array($sqldata, MYSQLI_ASSOC)){
    echo "<tr><td>";
    echo $row['peopleid'];
     echo "</td><td>";
    echo $row['firstname'];
     echo "</td><td>";
    echo $row['lastname'];
     echo "</td></tr>";
}
    echo "</table>";

?>

</body>
</html>